"""Crossword generator: data/<slug>.json -> out/<slug>.layout.json"""
import json, random, sys

def can_place(grid, N, word, r, c, dr, dc):
    L = len(word)
    er, ec = r + dr * (L - 1), c + dc * (L - 1)
    if er >= N or ec >= N or r < 0 or c < 0:
        return None
    # cell before and after must be empty
    br, bc = r - dr, c - dc
    if 0 <= br < N and 0 <= bc < N and grid[br][bc]:
        return None
    ar, ac = er + dr, ec + dc
    if 0 <= ar < N and 0 <= ac < N and grid[ar][ac]:
        return None
    crosses = 0
    for i, ch in enumerate(word):
        rr, cc = r + dr * i, c + dc * i
        cur = grid[rr][cc]
        if cur:
            if cur != ch:
                return None
            crosses += 1
        else:
            # perpendicular neighbours must be empty
            for pr, pc in ((rr + dc, cc + dr), (rr - dc, cc - dr)):
                if 0 <= pr < N and 0 <= pc < N and grid[pr][pc]:
                    return None
    return crosses

def place(grid, word, r, c, dr, dc):
    for i, ch in enumerate(word):
        grid[r + dr * i][c + dc * i] = ch

def bbox(placed):
    rs = [p['r'] + (p['dr'] * i) for p in placed for i in range(len(p['ans']))]
    cs = [p['c'] + (p['dc'] * i) for p in placed for i in range(len(p['ans']))]
    return min(rs), max(rs), min(cs), max(cs)

def attempt(words, N, target, rng):
    grid = [[None] * N for _ in range(N)]
    placed = []
    order = sorted(words, key=lambda w: (0 if w.get('must') else 1, -len(w['ans'])))
    musts = [w for w in order if w.get('must')]
    first = rng.choice(musts[:4]) if musts else order[0]
    order.remove(first); order.insert(0, first)
    r, c = N // 2, (N - len(first['ans'])) // 2
    place(grid, first['ans'], r, c, 0, 1)
    placed.append(dict(first, r=r, c=c, dr=0, dc=1))
    pool = order[1:]
    rng.shuffle(pool)
    pool.sort(key=lambda w: 0 if w.get('must') else 1)
    progress = True
    while progress and len(placed) < target:
        progress = False
        best = None
        tiers = [[w for w in pool if w.get('must')], pool]
        for tier in tiers:
            if best:
                break
            allc = []
            for w in tier:
                cands = []
                for p in placed:
                    for i, ch in enumerate(p['ans']):
                        for j, wch in enumerate(w['ans']):
                            if ch != wch:
                                continue
                            pr, pc = p['r'] + p['dr'] * i, p['c'] + p['dc'] * i
                            dr, dc = p['dc'], p['dr']  # perpendicular
                            r0, c0 = pr - dr * j, pc - dc * j
                            x = can_place(grid, N, w['ans'], r0, c0, dr, dc)
                            if x is not None and x >= 1:
                                mid = len(w['ans']) / 2
                                cr, cc = r0 + dr * mid, c0 + dc * mid
                                dist = abs(cr - N / 2) + abs(cc - N / 2)
                                score = x * 10 + len(w['ans']) * 0.2 - dist * 0.1 + rng.random() * 3
                                cands.append((score, w, r0, c0, dr, dc))
                allc.extend(cands)
            if allc:
                allc.sort(key=lambda t: -t[0])
                best = rng.choice(allc[:3])
        if best:
            # randomised greedy: pick among the top 3 candidates overall for diversity
            _, w, r0, c0, dr, dc = best
            place(grid, w['ans'], r0, c0, dr, dc)
            placed.append(dict(w, r=r0, c=c0, dr=dr, dc=dc))
            pool.remove(w)
            progress = True
    return grid, placed

def main(slug, seed=None):
    data = json.load(open(f'data/{slug}.json', encoding='utf-8'))
    N = data.get('size', 17)
    target = data.get('target_words', 20)
    words = [w for w in data['words'] if len(w['ans']) <= N]
    best = None
    rng = random.Random(seed)
    for t in range(300):
        grid, placed = attempt(words, N, target, rng)
        r0, r1, c0, c1 = bbox(placed)
        h, w = r1 - r0 + 1, c1 - c0 + 1
        area = h * w
        letters = sum(len(p['ans']) for p in placed)
        musts = sum(1 for p in placed if p.get('must'))
        score = len(placed) * 100 + musts * 150 - area * 0.5 - abs(h - w) * 3
        if best is None or score > best[0]:
            best = (score, grid, placed, (r0, r1, c0, c1))
    score, grid, placed, (r0, r1, c0, c1) = best
    # normalise to bbox
    H, W = r1 - r0 + 1, c1 - c0 + 1
    for p in placed:
        p['r'] -= r0; p['c'] -= c0
    # numbering: standard crossword numbering by start cell (row-major)
    starts = {}
    for p in placed:
        starts.setdefault((p['r'], p['c']), []).append(p)
    n = 0
    for key in sorted(starts):
        n += 1
        for p in starts[key]:
            p['num'] = n
    cells = [[None] * W for _ in range(H)]
    for p in placed:
        for i, ch in enumerate(p['ans']):
            cells[p['r'] + p['dr'] * i][p['c'] + p['dc'] * i] = ch
    out = dict(data, H=H, W=W, cells=cells, placed=placed)
    json.dump(out, open(f'out/{slug}.layout.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'{slug}: {len(placed)} words, grid {H}x{W}, score {score:.0f}')
    for row in cells:
        print(''.join(ch or '·' for ch in row))
    print('unused:', [w['ans'] for w in words if not any(p['ans'] == w['ans'] for p in placed)])

if __name__ == '__main__':
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 1)
