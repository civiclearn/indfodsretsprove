"""Render out/<slug>.layout.json -> out/<slug>.pdf (A4, 2 pages: puzzle + facit)"""
import json, sys, re, html, asyncio, base64, pathlib
from playwright.async_api import async_playwright

ROOT = pathlib.Path(__file__).parent

def font_css():
    css = []
    for w in (400, 600, 700, 800):
        for sub in ('latin', 'latin-ext'):
            b = base64.b64encode((ROOT / 'fonts' / f'inter-{sub}-{w}-normal.woff2').read_bytes()).decode()
            css.append(f"@font-face{{font-family:Inter;font-weight:{w};font-style:normal;src:url(data:font/woff2;base64,{b}) format('woff2');}}")
    return '\n'.join(css)

def full_name(w):
    if w.get('full'):
        return w['full']
    m = re.search(r'\(([^)]*)\)\s*$', w['clue'])
    if not m:
        return w['ans'].title()
    first = m.group(1)
    if first[0].isdigit():
        return w['ans'].title()
    ans = w['ans'].title().replace('Kierkegaard', 'Kierkegaard')
    return f"{first} {ans}"

def grid_svg(lay, cell, show_letters):
    H, W, cells = lay['H'], lay['W'], lay['cells']
    nums = {}
    for p in lay['placed']:
        nums[(p['r'], p['c'])] = p['num']
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W*cell}mm" height="{H*cell}mm" viewBox="0 0 {W*cell} {H*cell}" font-family="Inter">']
    for r in range(H):
        for c in range(W):
            if cells[r][c]:
                x, y = c * cell, r * cell
                out.append(f'<rect x="{x}" y="{y}" width="{cell}" height="{cell}" fill="#fff" stroke="#1d2a44" stroke-width="0.28"/>')
                if (r, c) in nums:
                    out.append(f'<text x="{x+0.7:.2f}" y="{y+2.35:.2f}" font-size="{cell*0.24:.2f}" font-weight="700" fill="#1d2a44">{nums[(r,c)]}</text>')
                if show_letters:
                    out.append(f'<text x="{x+cell/2:.2f}" y="{y+cell*0.72:.2f}" font-size="{cell*0.55:.2f}" font-weight="600" text-anchor="middle" fill="#1d2a44">{cells[r][c]}</text>')
    out.append('</svg>')
    return ''.join(out)

def clue_lists(lay):
    across = sorted([p for p in lay['placed'] if p['dc'] == 1], key=lambda p: p['num'])
    down = sorted([p for p in lay['placed'] if p['dr'] == 1], key=lambda p: p['num'])
    def block(title, items, key):
        li = ''.join(f'<li><b>{p["num"]}</b> {html.escape(p["clue"])} <span class="len">({len(p["ans"])})</span></li>' for p in items)
        return f'<div class="clues"><h3 class="{key}">{title}</h3><ol>{li}</ol></div>'
    return block('Vandret', across, 'across') + block('Lodret', down, 'down')

def facit_list(lay):
    across = sorted([p for p in lay['placed'] if p['dc'] == 1], key=lambda p: p['num'])
    down = sorted([p for p in lay['placed'] if p['dr'] == 1], key=lambda p: p['num'])
    def block(title, items, key):
        def row(p):
            fn = full_name(p)
            extra = f' <span class="who">— {html.escape(fn)}</span>' if fn.lower() != p['ans'].lower() else ''
            return f'<li><b>{p["num"]}</b> <span class="ans">{p["ans"]}</span>{extra}</li>'
        li = ''.join(row(p) for p in items)
        return f'<div class="clues"><h3 class="{key}">{title}</h3><ol>{li}</ol></div>'
    return block('Vandret', across, 'across') + block('Lodret', down, 'down')

def page_html(lay):
    cell = min(8.4, 178 / lay['W'], 128 / lay['H'])
    e = html.escape
    return f"""<!doctype html><html lang="da"><head><meta charset="utf-8"><title>{e(lay['title'])}</title>
<style>
{font_css()}
@page {{ size: A4; margin: 0; }}
* {{ box-sizing: border-box; }}
html, body {{ margin:0; padding:0; font-family: Inter, system-ui, sans-serif; color:#1d2a44; -webkit-print-color-adjust: exact; print-color-adjust: exact; }}
.page {{ width:210mm; height:297mm; padding:14mm 16mm 12mm; page-break-after: always; position:relative; display:flex; flex-direction:column; }}
.page:last-child {{ page-break-after: auto; }}
header {{ display:flex; justify-content:space-between; align-items:flex-end; border-bottom:0.6mm solid #1d2a44; padding-bottom:3mm; margin-bottom:5mm; }}
h1 {{ margin:0; font-size:22pt; font-weight:800; letter-spacing:-0.02em; line-height:1.1; }}
h1 span {{ color:#6b7280; font-weight:600; font-size:15pt; white-space:nowrap; }}
.kicker {{ font-size:8.5pt; font-weight:700; letter-spacing:0.12em; text-transform:uppercase; color:#8b2635; margin-bottom:1.5mm; }}
.meta {{ text-align:right; font-size:8pt; white-space:nowrap; color:#6b7280; line-height:1.45; }}
.note {{ font-size:8.5pt; color:#4b5563; margin:0 0 4mm; }}
.gridwrap {{ display:flex; justify-content:center; margin-bottom:5mm; }}
.cluecols {{ column-count:3; column-gap:6mm; column-fill:balance; flex:1; }}
.clues {{ margin-bottom:3mm; }}
.clues h3 {{ font-size:8pt; letter-spacing:0.12em; text-transform:uppercase; margin:0 0 1.5mm; padding:0.8mm 2mm; display:inline-block; color:#fff; border-radius:1mm; }}
h3.across {{ background:#1d3a6e; }} h3.down {{ background:#8b2635; }}
.clues ol {{ list-style:none; margin:0; padding:0; font-size:8.6pt; line-height:1.32; }}
.clues li {{ margin:0 0 1.4mm; padding-left:5mm; text-indent:-5mm; break-inside:avoid; }}
.clues li b {{ display:inline-block; width:5mm; text-indent:0; }}
.len {{ color:#9ca3af; }}
.ans {{ font-weight:700; letter-spacing:0.04em; }}
.who {{ color:#4b5563; }}
footer {{ margin-top:auto; border-top:0.3mm solid #d1d5db; padding-top:2.5mm; display:flex; justify-content:space-between; font-size:8pt; color:#6b7280; }}
footer b {{ color:#1d2a44; }}
.facit .cluecols {{ column-count:2; }}
.facit .gridwrap {{ margin-bottom:6mm; }}
.learn {{ font-size:8.5pt; color:#4b5563; margin:0 0 5mm; }}
</style></head><body>
<section class="page">
  <header>
    <div><div class="kicker">Krydsord nr. {lay['number']} · Indfødsretsprøven</div>
      <h1>{e(lay['title'])} <span>{e(lay['subtitle'])}</span></h1></div>
    <div class="meta">{e(lay['edition'])}<br>{e(lay['exam'])}</div>
  </header>
  <p class="note">{e(lay['note'])} Tallet i parentes er antal bogstaver.</p>
  <div class="gridwrap">{grid_svg(lay, cell, False)}</div>
  <div class="cluecols">{clue_lists(lay)}</div>
  <footer><span><b>CivicLearn</b> · civiclearn.com/indfodsret</span><span>Gratis · alle seks krydsord: indfodsretsprove.dk/krydsord</span></footer>
</section>
<section class="page facit">
  <header>
    <div><div class="kicker">Facit · Krydsord nr. {lay['number']}</div>
      <h1>{e(lay['title'])} <span>Løsning</span></h1></div>
    <div class="meta">{e(lay['edition'])}<br>{e(lay['exam'])}</div>
  </header>
  <p class="learn">Kunne du ikke alle? Hvert svar her kan blive til et spørgsmål i prøven. Slå dem op i læsematerialet – eller øv dem i CivicLearns spørgsmålsbank.</p>
  <div class="gridwrap">{grid_svg(lay, cell*0.75, True)}</div>
  <div class="cluecols">{facit_list(lay)}</div>
  <footer><span><b>CivicLearn</b> · civiclearn.com/indfodsret</span><span>Øv spørgsmålene: indfodsretsprove.dk</span></footer>
</section>
</body></html>"""

async def render(slug):
    lay = json.load(open(ROOT / 'out' / f'{slug}.layout.json', encoding='utf-8'))
    h = page_html(lay)
    (ROOT / 'out' / f'{slug}.html').write_text(h, encoding='utf-8')
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        await pg.set_content(h, wait_until='load')
        await pg.evaluate('document.fonts.ready')
        await pg.pdf(path=str(ROOT / 'out' / f'{slug}.pdf'), format='A4', print_background=True, prefer_css_page_size=True)
        await b.close()
    print('ok', slug)

if __name__ == '__main__':
    asyncio.run(render(sys.argv[1]))
